-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : db:3306
-- Généré le : mer. 18 déc. 2024 à 14:21
-- Version du serveur : 8.0.30
-- Version de PHP : 8.0.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `db_space_invaders`
--
CREATE DATABASE IF NOT EXISTS `db_space_invaders` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `db_space_invaders`;

-- --------------------------------------------------------

--
-- Structure de la table `ARMES`
--

CREATE TABLE `ARMES` (
  `armes_id` int NOT NULL,
  `nom` varchar(20) DEFAULT NULL,
  `description` varchar(60) DEFAULT NULL,
  `prix` int DEFAULT NULL,
  `force_armes` int DEFAULT NULL,
  `nb_max_coups` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `ARMES`
--

INSERT INTO `ARMES` (`armes_id`, `nom`, `description`, `prix`, `force_armes`, `nb_max_coups`) VALUES
(1, 'Epée longue', 'Une épée légère et rapide', 150, 25, 100),
(2, 'Arc Elfique', 'Arc de haute précision', 200, 15, 50),
(3, 'Marteau de Guerre', 'Marteau lourd', 300, 35, 30),
(4, 'Dague du Silence', 'Dague rapide et discrète', 80, 20, 120),
(5, 'Hache Double', 'Hache tranchante pour les combats rapprochés', 250, 40, 20),
(6, 'Sceptre Magique', 'Sceptre pour les magiciens', 180, 30, 60),
(7, 'Lance du Dragon', 'Lance de grande portée', 220, 28, 40),
(8, 'Arbalète', 'Arme à projectiles silencieuse', 130, 18, 70),
(9, 'Epée enflammée', 'Epée qui inflige des dégâts de feu', 270, 33, 80),
(10, 'Bouclier du Titan', 'Bouclier avec une grande résistance', 350, 10, 150),
(11, 'Claymore', 'Une épée massive à deux mains', 300, 45, 20),
(12, 'Arc de Chasseur', 'Arc léger et rapide pour les chasseurs', 120, 18, 60),
(13, 'Masse d’armes', 'Une masse brute pour briser les armures', 180, 40, 25),
(14, 'Dague du Voleur', 'Dague idéale pour les attaques furtives', 90, 22, 130),
(15, 'Hache à Double Tranc', 'Hache redoutable pour les combats rapprochés', 260, 42, 20),
(16, 'Sceptre de Glace', 'Sceptre magique pouvant lancer des éclats de glace', 200, 35, 50),
(17, 'Lance des Steppes', 'Lance légère et polyvalente', 160, 30, 45),
(18, 'Arbalète de Chasseur', 'Arbalète pour la précision à longue distance', 140, 20, 80),
(19, 'Epée de Légende', 'Epée mythique, très tranchante', 350, 50, 30),
(20, 'Bouclier de Fer', 'Bouclier en fer forgé offrant une bonne protection', 120, 8, 100),
(21, 'Sabre de Pirates', 'Sabre courbé, idéal pour les combats rapides', 170, 25, 70),
(22, 'Glaive de Garde', 'Glaive de garde royal, équilibre parfait entre attaque et dé', 220, 30, 55),
(23, 'Hache de Berserker', 'Hache lourde pour des attaques puissantes', 280, 50, 15),
(24, 'Lance de Guerre', 'Lance de grande taille pour les combats en ligne', 240, 38, 35),
(25, 'Arc Court', 'Arc compact pour les combats rapprochés', 100, 15, 70),
(26, 'Dague de l’Ombre', 'Dague parfaite pour les assassins', 110, 24, 140),
(27, 'Pique du Géant', 'Une pique gigantesque pour les combats de masse', 350, 55, 12),
(28, 'Fléau d’armes', 'Une arme composée de chaînes et de boules métalliques', 230, 36, 20),
(29, 'Arc de la Forêt', 'Arc décoré pour les archers sylvestres', 180, 25, 65),
(30, 'Manteau de Magicien', 'Manteau magique offrant des pouvoirs de protection', 120, 10, 150),
(31, 'Bâton de Feu', 'Bâton magique canalisant l’énergie du feu', 210, 40, 40),
(32, 'Épée à deux mains', 'Epée longue et lourde pour les guerriers puissants', 300, 45, 25),
(33, 'Dague en Argent', 'Dague légère avec une lame d’argent', 130, 20, 110),
(34, 'Hache de Guerre Runi', 'Hache ornée de runes magiques', 270, 45, 18),
(35, 'Flèche de Glace', 'Flèche magique capable de geler ses cibles', 80, 30, 120),
(36, 'Marteau d’Assaut', 'Un marteau de guerre pour des attaques lourdes', 320, 50, 10),
(37, 'Arc de Sombra', 'Arc magique tirant des flèches d’ombre', 210, 28, 55),
(38, 'Bouclier de Lumière', 'Bouclier empli de lumière protectrice', 250, 12, 100),
(39, 'Faucheuse', 'Grande faux aux pouvoirs maléfiques', 300, 60, 10),
(40, 'Pistolet Magique', 'Pistolet semi-magique à projectiles énergétiques', 280, 30, 20),
(41, 'Arc à répétition', 'Arc qui tire plusieurs flèches d’un coup', 260, 27, 45),
(42, 'Bâton de Vie', 'Bâton magique guérisseur', 180, 18, 70),
(43, 'Katana', 'Epée japonaise avec une lame ultra-tranchante', 350, 50, 30),
(44, 'Hache de Crâne', 'Hache dotée d’une lame en forme de crâne', 310, 48, 15),
(45, 'Guisarme', 'Longue lance avec une lame courbée pour trancher', 250, 38, 25),
(46, 'Lance de Garde', 'Lance utilisée par les soldats d’élite', 200, 32, 40),
(47, 'Dague de l’Assassin', 'Dague permettant des attaques furtives', 95, 20, 130),
(48, 'Bâton de Foudre', 'Bâton magique lançant des éclairs', 230, 42, 35),
(49, 'Rapière', 'Epée fine et rapide pour les duels', 170, 22, 90),
(50, 'Arc Long', 'Arc classique pour les archers expérimentés', 220, 35, 60);

-- --------------------------------------------------------

-- --------------------------------------------------------

--
-- Structure de la table `COMMANDE_ACHAT_ARMES`
--

CREATE TABLE `COMMANDE_ACHAT_ARMES` (
  `commande_id` int NOT NULL,
  `numero_commande` int DEFAULT NULL,
  `date_commande` date DEFAULT NULL,
  `joueurs_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `COMMANDE_ACHAT_ARMES`
--

INSERT INTO `COMMANDE_ACHAT_ARMES` (`commande_id`, `numero_commande`, `date_commande`, `joueurs_id`) VALUES
(1, 1001, '2024-01-15', 3),
(2, 1002, '2024-01-20', 5),
(3, 1003, '2024-02-01', 7),
(4, 1004, '2024-02-15', 10),
(5, 1005, '2024-02-20', 1),
(6, 1006, '2024-03-05', 2),
(7, 1007, '2024-03-10', 4),
(8, 1008, '2024-03-15', 6),
(9, 1009, '2024-03-20', 8),
(10, 1010, '2024-04-01', 9),
(11, 1011, '2024-04-05', 11),
(12, 1012, '2024-04-10', 12),
(13, 1013, '2024-04-15', 13),
(14, 1014, '2024-04-20', 14),
(15, 1015, '2024-05-01', 15),
(16, 1016, '2024-05-05', 16),
(17, 1017, '2024-05-10', 17),
(18, 1018, '2024-05-15', 18),
(19, 1019, '2024-05-20', 19),
(20, 1020, '2024-06-01', 20),
(21, 1021, '2024-06-05', 21),
(22, 1022, '2024-06-10', 22),
(23, 1023, '2024-06-15', 23),
(24, 1024, '2024-06-20', 24),
(25, 1025, '2024-07-01', 25),
(26, 1026, '2024-07-05', 26),
(27, 1027, '2024-07-10', 27),
(28, 1028, '2024-07-15', 28),
(29, 1029, '2024-07-20', 29),
(30, 1030, '2024-08-01', 30),
(31, 1031, '2024-08-05', 31),
(32, 1032, '2024-08-10', 32),
(33, 1033, '2024-08-15', 33),
(34, 1034, '2024-08-20', 34),
(35, 1035, '2024-09-01', 35),
(36, 1036, '2024-09-05', 36),
(37, 1037, '2024-09-10', 37),
(38, 1038, '2024-09-15', 38),
(39, 1039, '2024-09-20', 39),
(40, 1040, '2024-10-01', 40),
(41, 1041, '2024-10-05', 41),
(42, 1042, '2024-10-10', 42),
(43, 1043, '2024-10-15', 43),
(44, 1044, '2024-10-20', 44),
(45, 1045, '2024-11-01', 45),
(46, 1046, '2024-11-05', 46),
(47, 1047, '2024-11-10', 47),
(48, 1048, '2024-11-15', 48),
(49, 1049, '2024-11-20', 49),
(50, 1050, '2024-12-01', 50),
(51, 1051, '2024-12-05', 3),
(52, 1052, '2024-12-10', 3),
(53, 1053, '2024-12-15', 7),
(54, 1054, '2024-12-20', 10),
(55, 1055, '2024-12-25', 10),
(56, 1056, '2025-01-01', 15),
(57, 1057, '2025-01-05', 20),
(58, 1058, '2025-01-10', 20),
(59, 1059, '2025-01-15', 20),
(60, 1060, '2025-01-20', 25),
(61, 1061, '2025-01-25', 8),
(62, 1062, '2025-01-30', 8),
(63, 1063, '2025-02-01', 12),
(64, 1064, '2025-02-05', 12),
(65, 1065, '2025-02-10', 12),
(66, 1066, '2025-02-15', 18),
(67, 1067, '2025-02-20', 18),
(68, 1068, '2025-02-25', 22),
(69, 1069, '2025-03-01', 30),
(70, 1070, '2025-03-05', 30),
(71, 1071, '2025-03-10', 30),
(72, 1072, '2025-03-15', 35),
(73, 1073, '2025-03-20', 35),
(87, 1103, '2025-06-01', 6),
(88, 1106, '2025-06-05', 6),
(89, 1112, '2025-06-10', 6),
(90, 1118, '2025-06-15', 6),
(91, 1123, '2025-06-20', 9),
(92, 1127, '2025-06-25', 9),
(93, 1134, '2025-07-01', 9),
(94, 1139, '2025-07-05', 9),
(95, 1146, '2025-07-10', 9),
(96, 1152, '2025-07-15', 13),
(97, 1157, '2025-07-20', 13),
(98, 1163, '2025-07-25', 14),
(99, 1167, '2025-07-30', 14),
(100, 1172, '2025-08-01', 14),
(101, 1178, '2025-08-05', 14),
(102, 1184, '2025-08-10', 14),
(103, 1189, '2025-08-15', 14),
(104, 1195, '2025-08-20', 14),
(105, 1200, '2025-08-25', 14),
(106, 1207, '2025-08-30', 19),
(107, 1212, '2025-09-01', 19),
(108, 1218, '2025-09-05', 19),
(109, 1224, '2025-09-10', 21),
(110, 1230, '2025-09-15', 21),
(111, 1237, '2025-09-20', 21),
(112, 1243, '2025-09-25', 21),
(113, 1250, '2025-10-01', 21),
(114, 1256, '2025-10-05', 21),
(115, 1262, '2025-10-10', 23);

-- --------------------------------------------------------



--
-- Structure de la table `contenir`
--

CREATE TABLE `contenir` (
  `armes_id` int NOT NULL,
  `commande_id` int NOT NULL,
  `quantite_armes` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `contenir`
--

INSERT INTO `contenir` (`armes_id`, `commande_id`, `quantite_armes`) VALUES
(1, 12, 4),
(1, 51, 3),
(1, 62, 7),
(2, 45, 2),
(3, 6, 2),
(4, 28, 2),
(5, 9, 3),
(5, 52, 4),
(6, 21, 3),
(7, 30, 1),
(8, 4, 5),
(9, 16, 2),
(10, 27, 3),
(10, 53, 2),
(11, 18, 3),
(12, 41, 5),
(13, 24, 2),
(14, 2, 3),
(15, 48, 4),
(16, 20, 2),
(17, 8, 6),
(18, 33, 4),
(19, 14, 3),
(20, 47, 5),
(21, 5, 7),
(22, 23, 6),
(23, 39, 3),
(24, 15, 5),
(25, 29, 6),
(26, 44, 3),
(27, 1, 2),
(28, 19, 4),
(29, 40, 2),
(30, 26, 5),
(31, 32, 5),
(32, 46, 6),
(33, 17, 6),
(34, 49, 3),
(35, 36, 2),
(36, 10, 1),
(37, 35, 6),
(38, 37, 1),
(39, 3, 1),
(40, 34, 3),
(41, 25, 4),
(42, 11, 2),
(43, 31, 3),
(44, 38, 4),
(45, 22, 1),
(46, 50, 1),
(47, 42, 4),
(48, 43, 1),
(49, 7, 4),
(50, 13, 1),
(50, 61, 3);

-- --------------------------------------------------------

--
--
-- Structure de la table `JOUEURS`
--

CREATE TABLE `JOUEURS` (
  `joueurs_id` int NOT NULL,
  `pseudo` varchar(20) DEFAULT NULL,
  `nb_points` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `JOUEURS`
--

INSERT INTO `JOUEURS` (`joueurs_id`, `pseudo`, `nb_points`) VALUES
(1, 'DragonSlayer', 245),
(2, 'ShadowHunter', 130),
(3, 'WarriorQueen', 475),
(4, 'SteelKnight', 320),
(5, 'MageMaster', 155),
(6, 'FireFury', 210),
(7, 'IceWizard', 490),
(8, 'StormBringer', 350),
(9, 'NightStalker', 270),
(10, 'BladeMaster', 410),
(11, 'Phoenix', 180),
(12, 'DarkLord', 285),
(13, 'ElvenArcher', 105),
(14, 'RogueWarrior', 365),
(15, 'GoblinCrusher', 210),
(16, 'LightSorcerer', 475),
(17, 'DwarvenTank', 150),
(18, 'ArcaneAssassin', 290),
(19, 'Valkyrie', 220),
(20, 'WindRanger', 340),
(21, 'ThunderMage', 190),
(22, 'StormCaller', 310),
(23, 'ShadowKnight', 260),
(24, 'FireBreather', 430),
(25, 'WaterShaman', 380),
(26, 'SwordSaint', 275),
(27, 'ChaosMage', 360),
(28, 'BeastSlayer', 165),
(29, 'StoneGiant', 290),
(30, 'LightBear', 450),
(31, 'DarkRanger', 300),
(32, 'DesertWarrior', 210),
(33, 'IceGiant', 480),
(34, 'WindWalker', 125),
(35, 'BloodElf', 395),
(36, 'IronKnight', 220),
(37, 'CrystalMage', 330),
(38, 'SilverArrow', 200),
(39, 'Mystic', 410),
(40, 'FlameSeer', 315),
(41, 'BattleHawk', 260),
(42, 'TwilightAssassin', 270),
(43, 'ThunderFist', 310),
(44, 'StoneCaster', 185),
(45, 'SoulReaper', 275),
(46, 'RavenLord', 320),
(47, 'FrostSpirit', 210),
(48, 'SilentHunter', 350),
(49, 'LunarMage', 245),
(50, 'DeathBringer', 480);

-- --------------------------------------------------------

--
-- Structure de la table `posséder`
--

CREATE TABLE `posséder` (
  `joueurs_id` int NOT NULL,
  `armes_id` int NOT NULL,
  `nb_coups_restants` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `posséder`
--

INSERT INTO `posséder` (`joueurs_id`, `armes_id`, `nb_coups_restants`) VALUES
(1, 2, 30),
(2, 5, 15),
(3, 1, 50),
(4, 3, 25),
(5, 4, 60),
(6, 6, 40),
(7, 10, 45),
(8, 8, 55),
(9, 9, 20),
(10, 7, 35),
(11, 2, 60),
(12, 5, 40),
(13, 1, 70),
(14, 3, 35),
(15, 4, 80),
(16, 6, 50),
(17, 10, 60),
(18, 8, 45),
(19, 9, 30),
(20, 7, 50),
(21, 1, 45),
(22, 2, 25),
(23, 3, 55),
(24, 4, 70),
(25, 5, 20),
(26, 6, 30),
(27, 7, 65),
(28, 8, 40),
(29, 9, 50),
(30, 10, 75),
(31, 2, 35),
(32, 5, 60),
(33, 1, 80),
(34, 3, 50),
(35, 4, 25),
(36, 6, 45),
(37, 7, 60),
(38, 8, 30),
(39, 9, 65),
(40, 10, 40),
(41, 1, 30),
(42, 2, 50),
(43, 3, 60),
(44, 4, 40),
(45, 5, 45),
(46, 6, 70),
(47, 7, 30),
(48, 8, 50),
(49, 9, 60),
(50, 10, 30);

-- --------------------------------------------------------

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `ARMES`
--
ALTER TABLE `ARMES`
  ADD PRIMARY KEY (`armes_id`);

--


--
-- Index pour la table `COMMANDE_ACHAT_ARMES`
--
ALTER TABLE `COMMANDE_ACHAT_ARMES`
  ADD PRIMARY KEY (`commande_id`),
  ADD UNIQUE KEY `numero_commande` (`numero_commande`),
  ADD KEY `joueurs_id` (`joueurs_id`),
  ADD KEY `index_commande` (`commande_id`,`numero_commande`,`date_commande`);

--

--
-- Index pour la table `contenir`
--
ALTER TABLE `contenir`
  ADD PRIMARY KEY (`armes_id`,`commande_id`),
  ADD KEY `commande_id` (`commande_id`);



--
-- Index pour la table `JOUEURS`
--
ALTER TABLE `JOUEURS`
  ADD PRIMARY KEY (`joueurs_id`);

--

--
-- Index pour la table `posséder`
--
ALTER TABLE `posséder`
  ADD PRIMARY KEY (`joueurs_id`,`armes_id`),
  ADD KEY `armes_id` (`armes_id`);

--


--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `COMMANDE_ACHAT_ARMES`
--
ALTER TABLE `COMMANDE_ACHAT_ARMES`
  ADD CONSTRAINT `COMMANDE_ACHAT_ARMES_ibfk_1` FOREIGN KEY (`joueurs_id`) REFERENCES `JOUEURS` (`joueurs_id`);



--
-- Contraintes pour la table `contenir`
--
ALTER TABLE `contenir`
  ADD CONSTRAINT `contenir_ibfk_1` FOREIGN KEY (`armes_id`) REFERENCES `ARMES` (`armes_id`),
  ADD CONSTRAINT `contenir_ibfk_2` FOREIGN KEY (`commande_id`) REFERENCES `COMMANDE_ACHAT_ARMES` (`commande_id`);

--
-- Contraintes pour la table `posséder`
--
ALTER TABLE `posséder`
  ADD CONSTRAINT `posséder_ibfk_1` FOREIGN KEY (`joueurs_id`) REFERENCES `JOUEURS` (`joueurs_id`),
  ADD CONSTRAINT `posséder_ibfk_2` FOREIGN KEY (`armes_id`) REFERENCES `ARMES` (`armes_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
