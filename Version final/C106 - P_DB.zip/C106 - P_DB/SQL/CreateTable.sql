CREATE TABLE joueur(
   joueur_id INT,
   pseudo VARCHAR(20),
   nb_points INT,
   PRIMARY KEY(joueur_id)
);

CREATE TABLE arme(
   arme_id INT,
   nom VARCHAR(20),
   description VARCHAR(60),
   prix INT,
   force_arme INT,
   nb_max_coups INT,
   PRIMARY KEY(arme_id)
);

CREATE TABLE commande_achat_arme(
   commande_id INT,
   numero_commande INT,
   date_commande DATE,
   joueur_id INT NOT NULL,
   PRIMARY KEY(commande_id),
   UNIQUE(numero_commande),
   FOREIGN KEY(joueur_id) REFERENCES joueur(joueur_id)
);

CREATE TABLE posseder(
   joueur_id INT,
   arme_id INT,
   nb_coups_restants INT,
   PRIMARY KEY(joueur_id, arme_id),
   FOREIGN KEY(joueur_id) REFERENCES joueur(joueur_id),
   FOREIGN KEY(arme_id) REFERENCES arme(arme_id)
);

CREATE TABLE contenir(
   arme_id INT,
   commande_id INT,
   quantite_arme INT,
   PRIMARY KEY(arme_id, commande_id),
   FOREIGN KEY(arme_id) REFERENCES arme(arme_id),
   FOREIGN KEY(commande_id) REFERENCES commande_achat_arme(commande_id)
);
