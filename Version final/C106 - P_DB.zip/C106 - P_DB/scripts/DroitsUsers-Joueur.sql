GRANT SELECT, CREATE ON `db_space_invaders`.`COMMANDE_ACHAT_ARMES` TO 'Joueur'@'joueur'; ALTER USER 'Joueur'@'joueur' ;


GRANT SELECT ON `db_space_invaders`.`ARMES` TO 'Joueur'@'joueur'; ALTER USER 'Joueur'@'joueur' ;

GRANT SELECT ON ‘db_space_ invaders’.’ contenir’TO'Joueur'@'joueur'; ALTER USER 'Joueur'@'joueur' ;

GRANT SELECT ON ‘db_space_ invaders’.’ posseder’TO'Joueur'@'joueur'; ALTER USER 'Joueur'@'joueur' ;
