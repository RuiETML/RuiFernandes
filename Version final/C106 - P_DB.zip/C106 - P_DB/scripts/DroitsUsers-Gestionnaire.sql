GRANT SELECT, UPDATE, DELETE ON ‘db_space_invaders’.’ARMES’*TO’Gestionnaire de la boutique’@’gestionnaire’ ; ALTER USER ‘Gestionnaire de la boutique’@’gestionnaire’ ;

GRANT SELECT ON ‘db_space_ invaders’.’JOUEURS’TO’Gestionnaire de la boutique’@’gestionnaire’ ; ALTER USER ‘Gestionnaire de la boutique’@’gestionnaire’;

GRANT SELECT ON ‘db_space_ invaders’.’ COMMANDE_ACHAT_ARMES’TO’Gestionnaire de la boutique’@’gestionnaire’ ; ALTER USER ‘Gestionnaire de la boutique’@’gestionnaire’ ;

GRANT SELECT ON ‘db_space_ invaders’.’ contenir’TO’Gestionnaire de la boutique’@’gestionnaire’ ; ALTER USER ‘Gestionnaire de la boutique’@’gestionnaire’ ;

GRANT SELECT ON ‘db_space_ invaders’.’ posseder’TO’Gestionnaire de la boutique’@’gestionnaire’ ; ALTER USER ‘Gestionnaire de la boutique’@’gestionnaire’ ;
