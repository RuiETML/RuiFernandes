SHOW GRANTS FOR 'Administrateur_jeu'@'Admin';

SHOW GRANTS FOR 'Gestionnaire de la boutique'@'Gestionnaire';

SHOW GRANTS FOR 'Joueur'@'Joueur';