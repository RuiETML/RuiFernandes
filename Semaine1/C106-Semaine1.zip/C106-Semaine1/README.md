# RuiFernandes
Projet C106 de Rui - CIN2A
Première version du projet après la première séquence et donc séquence d'introduction.
Lors de cette séquence, le rapport a été crée, le MLD à été crée et validé, le journal de travail à été créé et remplie


MISE à JOUR 12.11.2024
Version du projet à la semaine 2
